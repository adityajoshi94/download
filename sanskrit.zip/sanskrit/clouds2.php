<?php
$var=$_GET['var'];
$var2=$_GET['var2'];
$var3 = $_GET['var3'];
include('recieve3.php');
include('clouds3.php');

?>
