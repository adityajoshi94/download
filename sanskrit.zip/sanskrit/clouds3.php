<html>
    <head>
        <script>
		function init()
			{	
			
		    var xp = <?php echo $xp; ?>;
			var yp = <?php echo $yp; ?>;
			alert(xp);
			alert(yp);
			myFunction(226,69,78,xp,yp,0,0,0,0.8);	
			}
		function myFunction(a,b,d,X,Y,r1,g1,b1,a1)
			{		
					//initialise R G B
				
					this.xp = X;
					this.yp = Y;
					this.R = a;
					this.G = b;
					this.B = d;
					
					var L = "(";
					var C = ",";
					var Rp = ")";
					var E = L ;
					var ic = "'";
					var prefix = "rgb";
					this.color = prefix + L + R+ C + G + C + B + Rp;
					var c=document.getElementById("myCanvas");
					var ctx=c.getContext("2d");
					ctx.clearRect(0,0,950,300);
					createRectangle(r1,g1,b1,a1);
					createClouds(80,180,140,80);
			        createClouds(400,180,460,80);
			        createClouds(690,180,750,80);
					ctx.beginPath();
					ctx.fillStyle = this.color;
					ctx.arc(xp,yp,30,0,Math.PI*2,true);
					ctx.closePath();
					ctx.fill();
					//Increase position of Sun in x and y direction
					
					increasePosition(xp,yp);
					changeBackground1();
					
					//possible short term evaluation
					if(ap<=200)
						{
						   if(a<= 186)
							{
							a = a+1;
							//R1=R1+1;
							}
							else
							{
							a = a+0;
							//R1=R1+0;
							}
							if(b<=126)	
							{
							b= b+1;
							//G1 = G1+1;
							}
							else
							{
							b = b+0;
							//G1 = G1+1;
							}
							
							if(d<=91)
							{
							d = d+1;
							//B1 = B1+1;
							}
							else
							{
							d = d+0;
							//B1 = B1+0;
							}
							t = setTimeout(function(){myFunction(a,b,d,ap,bp,R1,G1,B1,A1)}, 40);
						}
						else if((ap>200)&&(ap<=450))
						{
						   if(a<= 241)
							{
							a = a+3;
							//R1=R1+1;
							}
							else
							{
							a = a+0;
							//R1=R1+0;
							}
							if(b<=228)	
							{
							b= b+3;
							//G1 = G1+1;
							}
							else
							{
							b = b+0;
							//G1 = G1+1;
							}
							
							if(d<=190)
							{
							d = d+3;
							//B1 = B1+1;
							}
							else
							{
							d = d+0;
							//B1 = B1+0;
							}
							t = setTimeout(function(){myFunction(a,b,d,ap,bp,R1,G1,B1,A1)}, 40);
						}
						else if((ap>450)&&(ap<=550))
						{
						decreasePosition(xp,yp);
						t = setTimeout(function(){myFunction(a,b,d,ap,bp,R1,G1,B1,A1)}, 40);
						}
						else if((ap>550)&&(ap<=700))
						{
							decreasePosition(xp,yp);
							if(a>=255)
							{
							a = a-1;
							}
							else
							{
							a = a+0;
							}
							if(b>=141)	
							{
							b= b-1;
							}
							else
							{
							b = b+0;
							}
							if(d>=125)
							{
							d = d-1;
							}
							else
							{
							d = d+0;
							}
							t = setTimeout(function(){myFunction(a,b,d,ap,bp,R1,G1,B1,A1)}, 40);
						}
						else if(ap>700)
						{
							decreasePosition(xp,yp);
							if(a>=155)
							{
							a = a-1;
							}
							else
							{
							a = a+0;
							}
							if(b>=101)	
							{
							b= b-2;
							}
							else
							{
							b = b+0;
							}
							if(d>=85)
							{
							d = d-2;
							}
							else
							{
							d = d+0;
							}
						//	t = setTimeout(function(){myFunction(a,b,d,ap,bp,R1,G1,B1,A1)}, 40);
						}
				return;
			
			}	
		function increasePosition(xp,yp){

				ap = xp+3;
				bp = yp-1;
				
			}
		function decreasePosition(xp,yp){
			ap = xp+3;
			bp = yp+1;
		}
		
		function changeBackground1()
		{
			if(ap<=100){
			   if(R1<= 142)
				{
				R1=R1+1;
				}
				else
				{
				R1=R1+0;
				}
				if(G1<=214)	
				{
				G1 = G1+4;
				}
				else
				{
				G1 = G1+0;
				}
				if(B1<=255)
				{
				B1 = B1+6;
				}
				else
				{
				B1 = B1+0;
				}
				
			}
			else if((ap>100)&&(ap<=450))
			{
			 if(R1<= 174)
				{
				R1=R1+8;
				}
				else
				{
				R1=R1+0;
				}
				if(G1<=245)	
				{
				G1 = G1+4;
				}
				else
				{
				G1 = G1+0;
				}
				if(B1<=245)
				{
				B1 = B1+6;
				}
				else
				{
				B1 = B1+0;
				}
		
			}
			else if((ap>450)&&(ap<=700))
			{
				if(R1>=142)
				{
					R1=R1-3;
				}
				else{
					R1=R1-0;
				}
					
				if(G1>=214)	
				{
					G1 = G1-1;
				}
				else
				{
					G1 = G1+0;
				}
				if(B1>=255)
				{
				B1 = B1-1;
				}
				else
				{
					B1 = B1-0;
				}
		
		    }
			else if(ap>700)
			{
				if(R1>=70)
				{
					R1=R1-7;
				}
				else{
					R1=R1-0;
				}
					
				if(G1>=90)	
				{
					G1 = G1-7;
				}
				else
				{
					G1 = G1+0;
				}
				if(B1>=140)
				{
				B1 = B1-7;
				}
				else
				{
					B1 = B1-0;
				}
		
		    }
			//to check the exit value of R1,G1,B1 check following
		//	else
		//	{
		//	alert(R1);
		//	alert(G1);
		//	alert(B1);
		//	}
	}
		function createRectangle(R,G,B,A)
		{
		this.R1 = R;
		this.G1 = G;
		this.B1 = B;
		this.A1 = A;
		var L = "(";
		var C = ",";
		var Rp = ")";
		var E = L ;
		var ic = "'";
		var prefix = "rgba";
		this.colorR = prefix + L + R1+ C + G1 + C + B1 +C + A1 + Rp;
		//alert(colorR);
		var canvas = document.getElementById('myCanvas');
        var context = canvas.getContext('2d');
        context.beginPath();
        context.rect(0, 0, 950, 280);
        context.fillStyle = this.colorR ;
        context.fill();
        context.stroke();
		}
        function createClouds(startX,startY,grdCenterX,grdCenterY)
		{
                var canvas = document.getElementById("myCanvas");
                var context = canvas.getContext("2d");
                
                //var startX = 200;
               // var startY = 100;
                
                // draw cloud shape
                context.beginPath();
                context.moveTo(startX, startY);
                context.bezierCurveTo(startX - 40, startY + 20, startX - 40, startY + 70, startX + 60, startY + 70);
                context.bezierCurveTo(startX + 80, startY + 100, startX + 150, startY + 100, startX + 170, startY + 70);
                context.bezierCurveTo(startX + 250, startY + 70, startX + 250, startY + 40, startX + 220, startY + 20);
                context.bezierCurveTo(startX + 260, startY - 40, startX + 200, startY - 50, startX + 170, startY - 30);
                context.bezierCurveTo(startX + 150, startY - 75, startX + 80, startY - 60, startX + 80, startY - 30);
                context.bezierCurveTo(startX + 30, startY - 75, startX - 20, startY - 60, startX, startY);
                context.closePath();
               
                // add a radial gradient
               // var grdCenterX = 260;
               // var grdCenterY = 80;
                var grd = context.createRadialGradient(grdCenterX, grdCenterY, 10, grdCenterX, grdCenterY, 200);
                grd.addColorStop(0.1, "white");
				grd.addColorStop(.9, "#ffffff"); 
			    grd.addColorStop(.4, "white"); // light blue
               // dark blue
                context.fillStyle = grd;
                context.fill();
                
                // set the line width and stroke color
                context.lineWidth = 5;
                context.strokeStyle = (.2,"#ffffff");
                context.stroke();
            };
        </script>
    </head>
    <body onLoad="init();">
        <!--<canvas id="myCanvas" width="800" height="280" style="border:1px solid black; background-color: #eeeeee opacity: 0.7"> -->
		
		<canvas id="myCanvas" style="display:inline; float:left ; border: 0px solid #000000; background-color: #F5FFFA; opacity: 0.7;" width="950" height="280">Canvas is not supported</canvas>
		
    </body>
</html>
