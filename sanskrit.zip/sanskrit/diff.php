 <?php
$today = date("H:i"); 
echo $today;

$date = date("Y-m-d H:i:s");
echo $date;
 ?>