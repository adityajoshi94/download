<?php

# don't forget the library
    include('simple_html_dom.php');
// Create DOM from URL or file
echo"aditya";
$html = file_get_html('http://ibnlive.in.com/news/download-the-ibnlive-2012-calendar-with-indian-festivals-and-holidays/217124-53.html');

// Find all images 
foreach($html->find('img') as $element) 
       echo $element->src . '<br>';

// Find all links 
foreach($html->find('a') as $element) 
       echo $element->href . '<br>';
echo"trends";
//
foreach($html->find('div#headlinebox') as $e)
    echo $e->outertext . '<br>';

?>