<html>
<head>
<title></title>

<script language="Javascript">

async function logJSONData() {
    fetch('https://api.ipgeolocation.io/ipgeo?apiKey=7cf3b74ff6da49f388a8ca5c2730630f')
    .then(response =>response.json())
    .then(data =>        {  
        var x = data.latitude
        var y = data.longitude
        xmlhttpPost(x,y)
        console.log(x)
    
    })
    .catch( err => console.log(err) )
}

function startTime()
{
var today=new Date();
var h=today.getHours();
var m=today.getMinutes();
var s=today.getSeconds();
// add a zero in front of numbers<10
m=checkTime(m);
s=checkTime(s);
return h+":"+m;
//document.getElementById('txt').innerHTML=h+":"+m+":"+s;
//t=setTimeout(function(){startTime()},500);
}

function checkTime(i)
{
if (i<10)
  {
  i="0" + i;
  }
return i;
}
  

function xmlhttpPost(x,y) {
    var xmlHttpReq = false;
    var self = this;
    // Mozilla/Safari
    if (window.XMLHttpRequest) {
        self.xmlHttpReq = new XMLHttpRequest();
    }
    // IE
    else if (window.ActiveXObject) {
        self.xmlHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
    }
	
	//var x= (geoip_latitude());
	//var y=(geoip_longitude());
	var z = (new Date().getTimezoneOffset() * -1)/60;
    var current_time = startTime();
    console.log(current_time)
    console.log(z);
	URL = "recieve.php?var=" + x + "&var2=" + y + "&var3="+z + "&var4="+current_time;
    console.log("url" , URL)

    self.xmlHttpReq.open('POST', URL, true);
    self.xmlHttpReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    self.xmlHttpReq.onreadystatechange = function() {
        if (self.xmlHttpReq.readyState == 4) {
            updatepage(self.xmlHttpReq.responseText);
        }
    }
    self.xmlHttpReq.send(getquerystring());
}
function getquerystring() {
    var form     = document.forms['f1'];

}

function updatepage(str){
    document.getElementById("result").innerHTML = str;
}


</script>
</head>
<body>
<form name="f1">
  
  <script type="text/javascript" language="JavaScript">
       logJSONData();
      </script>
    <div id="result"> </div>
</form>


</body>
</html>

