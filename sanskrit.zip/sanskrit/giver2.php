<html>
<?php 
global $xp;
global $yp;

?>
<head>
<title></title>
<script language="JavaScript" src="http://j.maxmind.com/app/geoip.js"></script>
<script language="Javascript">
function xmlhttpPost() {



	var x= (geoip_latitude());
	var y=(geoip_longitude());
	var z = (new Date().getTimezoneOffset() * -1)/60;
	window.location.href = "clouds2.php?var=" + x + "&var2=" + y + "&var3="+z;

}



</script>
</head>
<body onLoad="xmlhttpPost();">

</body>
</html>

