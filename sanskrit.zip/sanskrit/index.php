<!DOCTYPE html>
<!--
Design by http://www.bluewebtemplates.com
Released for free under a Creative Commons Attribution 3.0 License
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	
	<title>Sanskrit-English Transliteration</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link href="style.css" rel="stylesheet" type="text/css" />
	<!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
	<script type="text/javascript" src="js/clock.js"></script>

<!-- Ajax related files -->
	<script type="text/javascript" src="js/ajaxsbmt.js"></script>
	<script type="text/javascript">
	<script src="https://code.jquery.com/jquery-3.6.4.js" integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E=" crossorigin="anonymous"></script>
	$(document).ready(function(){
		$('#slideshow').cycle({
			fx:     'fade',
			speed:  'slow',
			timeout: 3000,
			pager:  '#slider_nav',
			pagerAnchorBuilder: function(idx, slide) {
				// return sel string for existing anchor
				return '#slider_nav li:eq(' + (idx) + ') a';
			}
		});
	});
	
			function startTime()
			{
			var today=new Date();
			var h=today.getHours();
			var m=today.getMinutes();
			var s=today.getSeconds();
			// add a zero in front of numbers<10
			m=checkTime(m);
			s=checkTime(s);
			document.getElementById('txt').innerHTML=h+":"+m+":"+s;
			t=setTimeout('startTime()',500);
			}

			function checkTime(i)
			{
			if (i<10)
			  {
			  i="0" + i;
			  }
			return i;
			}
	</script>
			
	<!-- Placeholder -->

<!-- CuFon ends -->


</head>

<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
     <div class="logo"><h1><a href="index.php"><span>Sanskrit</span>WebPortal<br /><small>For English to Sanskrit Word Transliteration</small></a></h1></div>
      <div class="menu">
        <ul>
          <li class="active"><a href="index.php">Home</a></li>
          <li><a href="index_m.php">clock</a></li>
          <li><a href="">About Us</a></li>
          <li><a href="extract.php">Blog</a></li>
          <li><a href="">Contact Us</a></li>
        </ul>
      </div>
      <div class="clr"></div>
    </div>
  </div>

  <div class="hbg">
 	 <div class="hbg_resize">
		 <?php include('clouds.php'); ?>	
            
    </div>
  </div> 
 
 
   <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
			<h2><span>English Word</span></h2>	
			<form name="MyForm" action="" method="post"  onsubmit="xmlhttpPost('interface.php', 'MyForm', 'translated', '<img src=\'pleasewait.gif\'>'); return false;">
				<textarea placeholder=" Enter English word"  name="textarea" id="myTextarea" cols="40" rows="4"  ></textarea>
				<p><input name="send_button" type="submit" value="Send" /></p>
			</form>
		</div>
		<!---end of division article -->
		<script>
			if (!Modernizr.input.placeholder){
				  $('input[placeholder], textarea[placeholder]').placeholder();
			}
		</script>
        <div class="slider">
			<h2>Sanskrit Translation. </h2>
			<br />
			<h3> <div id="translated"></div></h3>   
			<br />
	
        </div>
		<hr />
      </div>

      <div class="sidebar">
        <div class="gadget">
          <h2 class="star"><span>Today</span></h2>
          <ul class="sb_menu">
			<b>
			<?php include('leap.php'); ?>		
			</b>
			<b>
			<?php include('weeks.php'); ?>		
			</b>
		 
		  </ul>
        </div>
       	<!---insertion point of division Gadget Sponsor Side bar -->
      </div>
      <div class="clr"></div>
    </div>
  </div>
  
  	<!---insertion point of division gbg class image gallery  -->
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright MyWebSite. Designed by Blue <a href="http://www.bluewebtemplates.com">Website Templates</a></p>
      <ul class="fmenu">
        <li class="active"><a href="index.php">Home</a></li>
        <li><a href="">Support</a></li>
        <li><a href="">Blog</a></li>
        <li><a href="">About Us</a></li>
        <li><a href="">Contacts</a></li>
      </ul>
    </div>
    <div class="clr"></div>
  </div>
</div>
</body>
</html>
