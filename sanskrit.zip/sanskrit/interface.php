
<HTML>
	<HEAD>
		<TITLE> Sanskrit Translation</TITLE>
	</HEAD>

	<body>
	
	 <?php 
		
		$str = $_POST['textarea'];
		$str = strtolower($str);
		//debug point to see the string entered at main page! echo $str;
		$cmd = "/usr/local/bin/pl -f /student/ajoshi8/public_html/translate.pl -g 'input($str)',halt 2>&1";
		// debug point to see execution command echo $cmd;
		$return_var = 0;
		$output = exec( $cmd ,$return_var);
		echo $output;
		echo $return_var;?>
	</body>
</HTML>
