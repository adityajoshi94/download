
<?php

$i =  date('L');

switch ($i) {
	case 0:
        $d = date('d');
		$m = Date('m');
		
		if(($m == 3&&$d>= 22)||($m == 4 && $d<21))
		{
		echo "Chaitra";
	    }
		if(($m == 4&&$d>= 21)||($m == 5 && $d<22))
		{
		echo "Vaisakha";
	    }
		if(($m == 5&&$d>= 22)||($m == 6 && $d<22))
		{
		echo "Jyaistha";
	    }
		if(($m == 6&&$d>= 22)||($m == 7 && $d<23))
		{
		echo "Asadha";
	    }
		if(($m == 7&&$d>= 23)||($m == 8 && $d<23))
		{
		echo "Shravana";
	    }
		if(($m == 8&&$d>= 23)||($m == 9&& $d<23))
		{
		echo "Bhadra";
	    }
		if(($m == 9&&$d>= 23)||($m == 10 && $d<23))
		{
		echo "Asvina";
	    }
		if(($m == 10&&$d>= 23)||($m == 11 && $d<22))
		{
		echo "Kartika";
	    }
		if(($m == 11&&$d>= 22)||($m == 12 && $d<22))
		{
		echo "Agrahayana";
	    }
		if(($m == 12&&$d>= 22)||($m == 1 && $d<22))
		{
		echo "Pausa";
	    }
		if(($m == 1&&$d>= 21)||($m == 2 && $d<20))
		{
		echo "Magha";
	    }
		if(($m == 20&&$d>= 20)||($m == 3&& $d<22))
		{
		echo "Phalguna";
	    }
		
        break;
    case 1:
	   echo('<br />');
	   echo "Date : ";
       echo date('Y-m-d');
	   echo('<br />');
	   echo "Month : ";
		$d = date('d');
		$m = Date('m');

		if(($m == 3&&$d>= 21)||($m == 4 && $d<21))
		{
		echo "Chaitra";
		}
		if(($m == 4&&$d>= 21)||($m == 5 && $d<22))
		{
		echo "Vaisakha";
		}
		if(($m == 5&&$d>= 22)||($m == 6 && $d<22))
		{
		echo "Jyaistha";
		}
		if(($m == 6&&$d>= 22)||($m == 7 && $d<23))
		{
		echo "Asadha";
		}
		if(($m == 7&&$d>= 23)||($m == 8 && $d<23))
		{
		echo "Shravana";
		}
		if(($m == 8&&$d>= 23)||($m == 9&& $d<23))
		{
		echo "Bhadra";
		}
		if(($m == 9&&$d>= 23)||($m == 10 && $d<23))
		{
		echo "Asvina";
		}
		if(($m == 10&&$d>= 23)||($m == 11 && $d<22))
		{
		echo "Kartika";
		}
		if(($m == 11&&$d>= 22)||($m == 12 && $d<22))
		{
		echo "Agrahayana";
		}
		if(($m == 12&&$d>= 22)||($m == 1 && $d<22))
		{
		echo "Pausa";
		}
		if(($m == 1&&$d>= 21)||($m == 2 && $d<20))
		{
		echo "Magha";
		}
		if(($m == 20&&$d>= 20)||($m == 3&& $d<22))
		{
		echo "Phalguna";
		}

		break;
		
 
}
?>





