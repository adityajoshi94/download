<?php


$var=$_GET['var'];
$var2=$_GET['var2'];
$var3 = $_GET['var3'];
$var4 = $_GET['var4'];


$current_time = $var4;
echo "\n";
$zenith=90+50/60;
//$time = (time()-1)-1980;

//$newtime = date('l jS \of F Y h:i:s A', $time);

$sunsrise = date_sunrise(time()-1980, SUNFUNCS_RET_STRING, $var, $var2, $zenith,$var3 );
$sunset = date_sunset(time()-1980, SUNFUNCS_RET_STRING, $var, $var2, $zenith, $var3);
// there are 24 hrs and first time division start at sun rise 24-6 =18 hr
// for finding the current mahurat i need current time , then i will find the difference between the sunrise and current time
//then i will divide 48 , which will give me an integer that will corrspond to mahurate
// time difference  aftermidnight and sunrise
$offset = (24- strtotime($sunsrise));
//echo $offset;
//echo "<br />";
// if current time is less than sunrise
// we will add current time and time when sunrises/ that means we are after midnight
$to_time = strtotime($var4);
$from_time = strtotime($sunsrise);
//echo "-".round(abs($to_time - $from_time) / 60,2). " minute";
//echo "-"."current_time".$var4;
if($current_time < $sunsrise)
{
//$C = $C+24;
$time_elapsed_since_sunrise = $current_time+ $offset;
//echo $C;
$sunsrise = date_sunrise(($time)-1980, SUNFUNCS_RET_STRING, $var, $var2, $zenith,$var3 );
//echo "<br />";
//echo $s;
//echo "<br />";
$M= (($time_elapsed_since_sunrise)*60)/48;
//echo $M;
//echo "<br />";
$M = (int)$M;
}
else{
$to_time = strtotime($current_time);
$from_time = strtotime($sunsrise);
$M= round(abs($to_time - $from_time) / 60,2)/48;
echo $M;
echo "<br />";
$M = (int)$M;
switch ($M) {
   
    case 1:
         echo "Mahurata:&nbsp;&nbsp;Ahi";
        break;
    case 2:
         echo "Mahurata:&nbsp;&nbsp;Mitra";
        break;
    case 3:
        echo "Mahurata:&nbsp;&nbsp;pitr";
        break;
    case 4:
        echo "Mahurata:&nbsp;&nbsp;vasu";
        break;
    case 5:
        echo "Mahurata:&nbsp;&nbsp;varah";
        break;
    case 6:
        echo "Mahurata:&nbsp;&nbsp;Visvadeva";
        break;
    case 7:
        echo "Mahurata:&nbsp;&nbsp;Vidhi";
        break;
    case 8:
        echo "Mahurata:&nbsp;&nbsp;Satamukhi";
        break;
    case 9:
        echo "Mahurata:&nbsp;&nbsp;Puruhuta";
        break;
    case 10:
        echo "Mahurata:&nbsp;&nbsp;Vahini";
        break;
    case 11:
        echo "Mahurata:&nbsp;&nbsp;Naktanakara";
        break;
    case 12:
        echo "Mahurata:&nbsp;&nbsp;Varuna";
        break;
    case 13:
        echo "Mahurata:&nbsp;&nbsp;Aryama";
        break;
    case 14:
        echo "Mahurata:&nbsp;&nbsp;Bhaga";
        break;
    case 15:
        echo "Mahurata:&nbsp;&nbsp;Girisa";
        break;
    case 16:
        echo "Mahurata:&nbsp;&nbsp;Ajapada";
        break;
    case 17:
        echo "Mahurata:&nbsp;&nbsp;Ahira Budhnya" ;
        break;
    case 18:
        echo "Mahurata:&nbsp;&nbsp;Pusa";
        break;
    case 19:
        echo "Mahurata:&nbsp;&nbsp;Asvini";
        break;
    case 20:
        echo "Mahurata:&nbsp;&nbsp;Yama";
        break;
    case 22:
        echo "Mahurata:&nbsp;&nbsp;Agni";
        break;
    case 23:
        echo "Mahurata:&nbsp;&nbsp;Vidhatr";
        break;
    case 24:
        echo "Mahurata:&nbsp;&nbsp;Kanda";
        break;
    case 25:
        echo "Mahurata:&nbsp;&nbsp;Aditi";
        break;
    case 26:
        echo "Mahurata:&nbsp;&nbsp;Jiva";
        break;
    case 27:
        echo "Mahurata:&nbsp;&nbsp;Visnu";
        break;
    case 28:
        echo "Mahurata:&nbsp;&nbsp;Yumigadyuti";
        break;
    case 29:
        echo "Mahurata:&nbsp;&nbsp;Brahma";
        break;
    case 30:
        echo "Mahurata:&nbsp;&nbsp;Samudrama";
        break;
}
}
echo"<br />";
echo "Today's Sunrise/Sunset";
echo"<br />";
echo"Sunrise at &nbsp;".$sunsrise."&nbsp;&nbsp;";
echo"<br />";
echo"Sunset at &nbsp;".$sunset."&nbsp;&nbsp;";
echo"<br />";
?>

