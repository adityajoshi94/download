<?php


$var=$_GET['var'];
$var2=$_GET['var2'];
$var3 = $_GET['var3'];


echo"Arrived";
$C = date("H:");echo "\n";
echo ("<br />");
echo "\n";
echo $C;
echo ("<br />");
echo "\n";
echo"After";
$C =$C-1;
echo ("<br />");
echo "\n";
echo $C;
echo ("<br />");
echo "\n";
echo "prvar3";
echo $var3;
echo ("<br />");
echo "\n";
$M= ($C);
$M = (int)$M;
switch ($M) {
 
    case 1:
         $xp = 0;
		 $yp = 200;
		 echo $xp.$yp;
        break;
    case 2:
         $xp = 55;
		 $yp = 180;
		 echo $xp.$yp;
        break;
    case 3:
         $xp =  110;
		 $yp =  160;
		 echo $xp.$yp;
        break;
    case 4:
         $xp =  165;
		 $yp =   140;
		 echo $xp.$yp;
        break;
    case 5:
         $xp =  215;
		 $yp =   120;
		 echo $xp.$yp;
        break;
    case 6:
         $xp =  265;
		 $yp =  100;
		 echo $xp.$yp;
        break;
    case 7:
		 $xp =  315;
		 $yp =  80;
		 echo $xp.$yp;
        break;
    case 8:
        $xp =  365;
		 $yp =  60;
		 echo $xp.$yp;
        break;
    case 9:
         $xp =  415;
		 $yp =  40;
		 echo $xp.$yp;
        break;
    case 10:
         $xp =  450;
		 $yp =  0;
		 echo $xp.$yp;
        break;
    case 11:
          $xp =  500;
		 $yp =  40;
		 echo $xp.$yp;
        break;
    case 12:
         $xp =  550;
		 $yp =  100;
		 echo $xp.$yp;
        break;
    case 13:
        $xp =  600;
		 $yp =  120;
		 echo $xp.$yp;
        break;
    case 14:
         $xp =  650;
		 $yp =  140;
		 echo $xp.$yp;
        break;
    case 15:
        $xp =  700;
		 $yp =  160;
		 echo $xp.$yp;
        break;
    case 16:
          $xp =  750;
		 $yp =  180;
		 echo $xp.$yp;
        break;
    case 17:
          $xp =  800;
		 $yp =  200;
		 echo $xp.$yp;
		
	
        break;
    case 18:
	
        $xp =  850;
		 $yp =  220;
		 echo $xp.$yp;
		 $GLOBALS['xr'] = $GLOBALS['xp'];
         $GLOBALS['yr'] = $GLOBALS['yp'];
		 echo ("<br />");
		 echo "\n";
		
        break;
    case 19:
        $xp =  900;
		$yp =  240;
		echo ("<br />");
		 echo "\n";
		 echo $xp.$yp;
		 echo ("value send from rec page");
		 echo "\n";
        break;
    case 20:
         $xp =  950;
		$yp =  260;
		echo $xp.$yp;
        break;
   

}



?>

