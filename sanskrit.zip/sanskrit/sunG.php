<html>
<head>
<title></title>
<script language="JavaScript" src="http://j.maxmind.com/app/geoip.js"></script>
<script language="Javascript">
function xmlhttpPost() {
    var xmlHttpReq = false;
    var self = this;
    // Mozilla/Safari
    if (window.XMLHttpRequest) {
        self.xmlHttpReq = new XMLHttpRequest();
    }
    // IE
    else if (window.ActiveXObject) {
        self.xmlHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
    }
	


	var x= (geoip_latitude());
	var y=(geoip_longitude());
	var z = (new Date().getTimezoneOffset() * -1)/60;
	URL = "sunR.php?var=" + x + "&var2=" + y + "&var3="+z;

    self.xmlHttpReq.open('POST', URL, true);
    self.xmlHttpReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    self.xmlHttpReq.onreadystatechange = function() {
        if (self.xmlHttpReq.readyState == 4) {
            updatepage(self.xmlHttpReq.responseText);
        }
    }
    self.xmlHttpReq.send(getquerystring());
}
function getquerystring() {
    var form     = document.forms['f1'];

}

function updatepage(str){
    document.getElementById("result").innerHTML = str;
}


</script>
</head>
<body>
<form name="f1">
  
  <script type="text/javascript" language="JavaScript">
       xmlhttpPost();
      </script>
    <div id="result"> </div>
</form>


</body>
</html>

