<?php


$var=$_GET['var'];
$var2=$_GET['var2'];
$var3 = $_GET['var3'];


$C = date("H:");echo "\n";
$zenith=90+50/60;
$time = time()-1980;

$newtime = date('l jS \of F Y h:i:s A', $time);

$s = date_sunrise(time()-1980, SUNFUNCS_RET_STRING, $var, $var2, $zenith,$var3 );
$ss = date_sunset(time()-1980, SUNFUNCS_RET_STRING, $var, $var2, $zenith, $var3);
echo '"'.$ss.'"';


?>

