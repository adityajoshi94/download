<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<link href="styles_t.css" rel="stylesheet" type="text/css" />
<script src="js/ajaxsbmt.js" type="text/javascript"></script>
</head>

<body>


 	<div id="page-wrap">
 	
 		<div id="header">
 			<h1>Sanskrit-English</h1>
 			<h4>Word-Translator</h4>
 		</div>
 		
 		<ul id="navbar">
 			<li><a href="index.php">Translator</a></li>
 			<li><a href="times.php">Sanskrit Divion of time and 				mahurat</a></li>
		</ul>

 	<div id="banner">
 				<h3><?php 
					$time = time()-1980;
				$newtime = date('l jS \of F Y h:i:s A', $time);
				echo $newtime;

				?></h3>
 			<h4></p>Weekday&nbsp;&nbsp;-&nbsp;<?php include('weeks.php')?>&nbsp;&nbsp;&nbsp;Month&nbsp;-&nbsp<?php include('leap.php')?></p></h4>
<h4><?php include('giver.php') ?></h4>
<p></p>

<br/>
			
</div> 
<div>
	<ul id="banlist">
 				
 	 			</ul>
 			<a href="#" id="banbut">Learn More</a>	
</div>
	
 
 		<div id="footer" class="clear">
 			<p class="left">�Sanskrit Translation. All Rights Reserved.</p>
 			<p class="right"><a href="#">Contact Us</a> | <a href="#">Webmaster</a></p>
 		</div>
 	

</body>

</html>
