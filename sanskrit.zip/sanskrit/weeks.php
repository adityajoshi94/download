<?php  
  // 1. Ravi�ra: Sunday (day of Sun)
   // 2. Somav�ra: Monday (day of Moon)
   // 3. Ma�galv�: Tuesday (day of Mars)
   // 4. Budhav�ra: Wednesday (day of Mercury)
   // 5. Guruv�ra: Thursday (day of Jupiter)
   // 6. Sukrav�ra: Friday (day of Venus)
   // 7. Saniv�ra: Saturday (day of Saturn)
   
   
   
   

$w = Date('D');



	
$a = array(
    "Sun" => 'Raviara',
    "Mon" => 'Somavara',
    "Tues" => 'Ma�galva',
    "Wed" =>'Budhavara' ,
    "Thu"=>'Guruvara',
    "Fri"=>'Sukravara',
    "Sat"=>'Sanivara'
);
echo("<br />");
echo("Day :");
foreach ($a as $k => $v) {
	if($k == $w) 
    echo  $v;
}
   

 ?>